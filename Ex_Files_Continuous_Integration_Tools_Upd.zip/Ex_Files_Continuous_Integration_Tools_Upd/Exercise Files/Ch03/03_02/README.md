# Azure Pipelines
[![Build Status](https://dev.azure.com/automate6500/azure-pipelines-demo/_apis/build/status/azure-pipelines-demo?branchName=master)](https://dev.azure.com/automate6500/azure-pipelines-demo/_build/latest?definitionId=5&branchName=master)

Files for Azure Pipelines
